const dummyData = [
    { id: 1, name: 'Iphone', desc:"Brand New Iphone 15 Pro", price: 75000,image:"/iphone.jpg",isChecked:false },
    { id: 2, name: 'Nike', desc:"Brand New Nike Running Shoes", price: 7200,image:"/nike.jpg",isChecked:false },
    { id: 3, name: 'Gym Vest', desc:"Brand New Gym Vest", price: 1200,image:"/vest1.jpg.crdownload",isChecked:false },
    { id: 4, name: 'Joggers', desc:"Brand New Joggers For Gym", price: 800,image:"/jog.jpeg",isChecked:false },
  ];
  
  export default dummyData;
  