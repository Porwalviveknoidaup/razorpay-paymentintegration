import './App.css';
import Shop from './components/Shop';

function App() {
  return (
    <div className="App">
      <Shop />
    </div>
  );
}

export default App;
